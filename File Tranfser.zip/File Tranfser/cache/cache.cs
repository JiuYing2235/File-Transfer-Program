﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography.Xml;
using System.Text;
using CacheGUI;
using Microsoft.VisualBasic.ApplicationServices;

namespace cache
{
    public class Cache
    {
        public static TcpClient cache1;

        public void cacheFrom()
        {
            new CacheForm().ShowDialog();
        }
        static void Main()
        {

            // Listen IP address. The Loopback is the local host
            IPAddress ipAddr = IPAddress.Loopback;

            // Listening port
            int port = 8082;

            // Create and start a listener for the cache connection
            TcpListener listener = new TcpListener(ipAddr, port);
            listener.Start();


            // keep running
            while (true)
            {
                var client = listener.AcceptTcpClient();

                // The NetworkStream object is used to transfer data between the client and the cache
                NetworkStream stream = client.GetStream();

                // Read the first byte representing the client command
                byte command = (byte)stream.ReadByte();

                // Forward commands to the server
                if (command == 0)
                {
                    TcpClient serverClient = new TcpClient("localhost", 8081);
                    NetworkStream serverStream = serverClient.GetStream();
                    serverStream.WriteByte(command);

                    byte[] serverResponse1 = new byte[1024];
                    int bytesRead = serverStream.Read(serverResponse1, 0, serverResponse1.Length);
                    while (bytesRead > 0)
                    {
                        stream.Write(serverResponse1, 0, bytesRead);
                        bytesRead = serverStream.Read(serverResponse1, 0, serverResponse1.Length);
                    }
                    serverStream.Close();
                    stream.Close();
                    client.Close();
                }
                if (command == 1)
                {
                    // The four bytes after the command are the number of bytes stored in the file name
                    byte[] data = new byte[4];
                    stream.Read(data, 0, 4);

                    // Find the length of the file name and read the bytes representing the file name
                    int fileNameBytesLength = BitConverter.ToInt32(data, 0);
                    data = new byte[fileNameBytesLength];
                    stream.Read(data, 0, fileNameBytesLength);

                    
                    string fileName = Encoding.UTF8.GetString(data);

                    // Check whether the file is cached
                    string path = Path.Combine(Directory.GetCurrentDirectory(), "../../../copydata");
                    string filePath = Path.Combine(path, fileName);
                    if (File.Exists(filePath))
                    {
                        // file exist
                        // Record logs in the log.txt file
                        string logFilePath = Path.Combine(path, "log.txt");
                        using (StreamWriter writerlog = new StreamWriter(logFilePath, true))
                        {
                            string logText = string.Format("user request: file {0} at {1}\n" + "response: cached file {0}", fileName, DateTime.Now.ToString());
                            writerlog.WriteLine(logText);
                        }

                        // The StreamWriter object is used to send data to the client
                        StreamWriter writer = new StreamWriter(stream);

                        // Reads the contents of the file and sends it to the cache
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {
                                // Writes this line to the network stream
                                writer.WriteLine(line);
                            }
                        }
                    }
                    else
                    {
                        // file not exist
                        byte command1 = 1;
                        byte[] fileNameBytes = Encoding.UTF8.GetBytes(fileName);
                        // Stores the number of bytes representing the file name as a 4-element byte array, since int is 4 bytes long
                        byte[] fileNameLengthBytes = BitConverter.GetBytes(fileNameBytes.Length);

                        byte[] data1 = new byte[5 + fileNameBytes.Length];
                        // Copy the command, length, and file name into the array to be sent to the server
                        data1[0] = command1;
                        Array.Copy(fileNameLengthBytes, 0, data1, 1, fileNameLengthBytes.Length);
                        Array.Copy(fileNameBytes, 0, data1, 5, fileNameBytes.Length);

                        cache1 = new TcpClient("localhost", 8081); // Create a new connection  

                        using (NetworkStream stream1 = cache1.GetStream())
                        {
                            // send data to server
                            stream1.Write(data1, 0, data1.Length);
                            stream1.Flush();

                            StreamWriter writer1 = new StreamWriter(stream);

                            byte[] data2 = new byte[1024];
                            stream1.Read(data2, 0, data2.Length);
                            string data2Detail = Encoding.UTF8.GetString(data2);

                            // Writes this line to the network stream

                            writer1.Write(data2Detail);
                            writer1.Flush();

                            // Record logs in the log.txt file
                            string pathfile = Path.Combine(Directory.GetCurrentDirectory(), "../../../copydata");
                            string logFilePath = Path.Combine(pathfile, "log.txt");
                            using (StreamWriter writerlog1 = new StreamWriter(logFilePath, true))
                            {
                                string logText = string.Format("user request: file {0} at {1}\nresponse: file {0} downloaded from the server", fileName, DateTime.Now.ToString());
                                writerlog1.WriteLine(logText);
                            }

                            // The StreamReader object is used to receive replies from the server
                            string cacheFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "../../../copydata");
                            string filePath1 = Path.Combine(cacheFolderPath, fileName);

                            // Create a file and write its contents
                            using (StreamWriter writer = new StreamWriter(filePath1))
                            {
                                writer.Write(data2Detail);
                            }

                            stream.Close();
                            stream1.Close();
                            client.Close();
                        }
                    }
                }
            }
        }
    }
}