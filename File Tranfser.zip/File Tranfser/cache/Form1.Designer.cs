﻿namespace CacheGUI
{
    public partial class CacheForm
    {
        public System.ComponentModel.IContainer components = null;
        public System.Windows.Forms.TextBox txtLog;
        public System.Windows.Forms.Button btnClearCache;
        public System.Windows.Forms.ListBox lstFiles;

        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.btnClearCache = new System.Windows.Forms.Button();
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(12, 12);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(600, 100);
            this.txtLog.TabIndex = 0;
            // 
            // btnClearCache
            // 
            this.btnClearCache.Location = new System.Drawing.Point(12, 118);
            this.btnClearCache.Name = "btnClearCache";
            this.btnClearCache.Size = new System.Drawing.Size(100, 30);
            this.btnClearCache.TabIndex = 1;
            this.btnClearCache.Text = "Clear Cache";
            this.btnClearCache.UseVisualStyleBackColor = true;
            this.btnClearCache.Click += new System.EventHandler(this.btnClearCache_Click);
            // 
            // lstFiles
            // 
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.Location = new System.Drawing.Point(12, 157);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(600, 173);
            this.lstFiles.TabIndex = 2;
            // 
            // CacheForm
            // 
            this.ClientSize = new System.Drawing.Size(650, 342);
            this.Controls.Add(this.lstFiles);
            this.Controls.Add(this.btnClearCache);
            this.Controls.Add(this.txtLog);
            this.Name = "CacheForm";
            this.Text = "Cache Form";
            this.Load += new System.EventHandler(this.CacheForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
