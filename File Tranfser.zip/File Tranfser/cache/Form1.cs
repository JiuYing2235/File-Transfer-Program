using System;
using System.IO;
using System.Windows.Forms;

namespace CacheGUI
{
    public partial class CacheForm : Form
    {
        public string cachePath = "../../../../cache/copydata";

        public CacheForm()
        {
            InitializeComponent();
        }

        public void CacheForm_Load(object sender, EventArgs e)
        {
            UpdateLog();
            UpdateFileList();
        }

        public void btnClearCache_Click(object sender, EventArgs e)
        {
            ClearCache();
            UpdateLog();
            UpdateFileList();
        }

        public void UpdateLog()
        {
            string logPath = Path.Combine(cachePath, "log.txt");
            if (File.Exists(logPath))
            {
                string logText = File.ReadAllText(logPath);
                logText = logText.Replace("\n", Environment.NewLine);
                txtLog.Text = logText;
            }
            else
            {
                txtLog.Text = "Log not found.";
            }
        }

        public void UpdateFileList()
        {
            lstFiles.Items.Clear();
            string[] fileNames = Directory.GetFiles(cachePath);
            foreach (string fileName in fileNames)
            {
                lstFiles.Items.Add(Path.GetFileName(fileName));
            }
        }

        public void ClearCache()
        {
            string[] fileNames = Directory.GetFiles(cachePath);
            foreach (string fileName in fileNames)
            {
                File.Delete(fileName);
            }
            File.WriteAllText(Path.Combine(cachePath, "log.txt"), "Cache cleared at " + DateTime.Now.ToString() + "\n");
        }
    }
}
