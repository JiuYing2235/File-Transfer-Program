﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography.Xml;
using System.Text;

namespace server
{
    class Server
    {
        public static void Server1()
        {
            // Listen IP address. The Loopback is the local host
            IPAddress ipAddr = IPAddress.Loopback;

            // Listening port
            int port = 8081;

            // Create and start a listener for the cache connection
            TcpListener listener = new TcpListener(ipAddr, port);
            listener.Start();

            // keep running
            while (true)
            {
                var client = listener.AcceptTcpClient();

                // The NetworkStream object is used to transfer data between the cache and the server
                NetworkStream stream = client.GetStream();

                // Reads the first byte of the cache command
                byte command = (byte)stream.ReadByte();

                // 0: Get the file list
                if (command == 0)
                {
                    // Gets all the text filenames in the data directory
                    string[] filePaths = Directory.GetFiles("../../../data", "*.txt");
                    string[] fileNames = new string[filePaths.Length];

                    for (int i = 0; i < filePaths.Length; i++)
                    {
                        fileNames[i] = Path.GetFileName(filePaths[i]);
                    }

                    // Create a StreamWriter object and write messages to the stream using UTF-8 encoding
                    StreamWriter writer = new StreamWriter(stream, Encoding.UTF8);

                    // Write all filenames into the stream separated by commas
                    string fileList = string.Join(",", fileNames);
                    writer.Write(fileList);

                    // Refresh the StreamWriter to ensure that all data is written to the stream
                    writer.Flush();
                }

                if (command == 1)
                {
                    byte[] data = new byte[4];
                    stream.Read(data, 0, 4);

                    // Find the length of the file name and read the bytes representing the file name
                    int fileNameBytesLength = BitConverter.ToInt32(data, 0);
                    data = new byte[fileNameBytesLength];
                    stream.Read(data, 0, fileNameBytesLength);

                    // Obtain the path to the file
                    string fileName = Encoding.UTF8.GetString(data);
                    string path = Path.Combine(Directory.GetCurrentDirectory(), "../../../data");
                    string fileNamePath = Path.Combine(path, fileName);

                    // StreamWriter object is used to send data to the cache
                    StreamWriter writer = new StreamWriter(stream);

                    // Reads the contents of the file and sends it to the cache
                    using (StreamReader reader = new StreamReader(fileNamePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            writer.WriteLine(line);
                        }
                    }
                    writer.Close();
                    stream.Close();
                }
                client.Close();
            }
        }
    }
}