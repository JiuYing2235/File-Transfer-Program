﻿namespace server
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private Button button1;
        private Button button2;
        private Button button3;
        private OpenFileDialog openFileDialog1;
        private TextBox textBox1;

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new Button();
            this.button2 = new Button();
            this.openFileDialog1 = new OpenFileDialog();
            this.textBox1 = new TextBox();

            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Text = "Server GUI";

            // set Button1
            this.button1.Location = new System.Drawing.Point(50, 50);
            this.button1.Size = new System.Drawing.Size(200, 50);
            this.button1.Text = "Start Server";
            this.button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.button1.Click += new System.EventHandler(this.button1_Click);

            // set Button2
            this.button2.Location = new System.Drawing.Point(50, 120);
            this.button2.Size = new System.Drawing.Size(200, 50);
            this.button2.Text = "Select File";
            this.button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.button2.Click += new System.EventHandler(this.button2_Click);

            // set TextBox
            this.textBox1.Multiline = true;
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = ScrollBars.Vertical;
            this.textBox1.Width = 500;
            this.textBox1.Height = 400;
            this.textBox1.Text = "Welcome to the Server!";
            this.textBox1.Location = new Point(280, 80);
            this.textBox1.Font = new Font("Segoe UI", 12F);

            // set OpenFileDialog
            this.openFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            this.openFileDialog1.Title = "Select a File";

            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
        }

        // button1
        private void button1_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(new ThreadStart(Server.Server1));
            thread.Start();
        }

        // button2
        private void button2_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string selectedFile = this.openFileDialog1.FileName;
                string destinationFolder = Path.Combine(Directory.GetCurrentDirectory(), "../../../data");
                string destinationFile = Path.Combine(destinationFolder, Path.GetFileName(selectedFile));

                try
                {
                    File.Copy(selectedFile, destinationFile, true);
                    MessageBox.Show("File copied successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("File copy failed: " + ex.Message);
                }
            }
        }
    }
}
