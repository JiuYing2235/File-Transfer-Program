﻿using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace client
{
    partial class Form1
    {
        private Button btnGetFiles;
        private ListBox lstFiles;
        private Button btnDownload;
        private Button btnCache;
        private TextBox txtFileContents;

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnGetFiles = new System.Windows.Forms.Button();
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.btnDownload = new System.Windows.Forms.Button();
            this.btnCache = new System.Windows.Forms.Button();
            this.txtFileContents = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnGetFiles
            // 
            this.btnGetFiles.Location = new System.Drawing.Point(12, 12);
            this.btnGetFiles.Name = "btnGetFiles";
            this.btnGetFiles.Size = new System.Drawing.Size(100, 23);
            this.btnGetFiles.TabIndex = 0;
            this.btnGetFiles.Text = "Get Available Files";
            this.btnGetFiles.UseVisualStyleBackColor = true;
            this.btnGetFiles.Click += new System.EventHandler(this.btnGetFiles_Click);
            // 
            // lstFiles
            // 
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.Location = new System.Drawing.Point(12, 41);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(200, 160);
            this.lstFiles.TabIndex = 1;
            // 
            // btnDownload
            // 
            this.btnDownload.Location = new System.Drawing.Point(12, 207);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(100, 23);
            this.btnDownload.TabIndex = 2;
            this.btnDownload.Text = "Download File";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnCache
            // 
            this.btnCache.Location = new System.Drawing.Point(12, 240);
            this.btnCache.Name = "btnCache";
            this.btnCache.Size = new System.Drawing.Size(100, 23);
            this.btnCache.TabIndex = 3;
            this.btnCache.Text = "Open Cache";
            this.btnCache.UseVisualStyleBackColor = true;
            this.btnCache.Click += new System.EventHandler(this.btnCache_Click);
            // 
            // txtFileContents
            // 
            this.txtFileContents.Location = new System.Drawing.Point(218, 12);
            this.txtFileContents.Multiline = true;
            this.txtFileContents.Name = "txtFileContents";
            this.txtFileContents.Size = new System.Drawing.Size(400, 300);
            this.txtFileContents.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 327);
            this.Controls.Add(this.txtFileContents);
            this.Controls.Add(this.btnDownload);
            this.Controls.Add(this.lstFiles);
            this.Controls.Add(this.btnGetFiles);
            this.Controls.Add(this.btnCache);
            this.Name = "Form1";
            this.Text = "File Downloader";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }

}