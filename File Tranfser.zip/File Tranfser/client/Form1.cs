using System.Net.Sockets;
using System.Net;
using System.Text;
using cache;
using System.IO;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace client
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private StreamReader reader;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnGetFiles_Click(object sender, EventArgs e)
        {
            try
            {
                // Connect to cache
                client = new TcpClient("localhost", 8082);
                stream = client.GetStream();
                reader = new StreamReader(stream);

                // Send command to get list of available files
                byte[] commandBytes = new byte[1] { 0 };
                stream.Write(commandBytes, 0, commandBytes.Length);

                // Receive list of available files
                string response = reader.ReadLine();
                string[] files = response.Split(',');

                // Display list of available files
                lstFiles.Items.Clear();
                lstFiles.Items.AddRange(files);

                // Clean up
                reader.Close();
                stream.Close();
                client.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            try
            {
                byte command = 1;
                // Send command to download selected file
                string? fileName = lstFiles.SelectedItem?.ToString();
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Please select a file to download.");
                    return;
                }
                // Text needs to be sent as a binary number
                // We store the file name in a binary array
                byte[] fileNameBytes = Encoding.UTF8.GetBytes(fileName);
                // Stores the number of bytes representing the file name as a 4-element byte array, since int is 4 bytes long
                byte[] fileNameLengthBytes = BitConverter.GetBytes(fileNameBytes.Length);
                // Create a new byte array to hold the data to be sent to the server
                // Element 0 is a command
                // Elements 1 through 4 are the length of the file name in bytes
                // The remaining elements represent file names
                byte[] data = new byte[5 + fileNameBytes.Length];
                // Copy the command, length, and file name into the array to be sent to the server
                data[0] = command;
                Array.Copy(fileNameLengthBytes, 0, data, 1, fileNameLengthBytes.Length);
                Array.Copy(fileNameBytes, 0, data, 5, fileNameBytes.Length);
                client = new TcpClient("localhost", 8082); // Create a new connection  

                using (NetworkStream stream = client.GetStream())
                {
                    // send data to cache
                    stream.Write(data, 0, data.Length);
                    stream.Flush();
                    // The StreamReader object is used to receive replies from the cache
                    byte[] data1 = new byte[1024];
                    stream.Read(data1, 0, data1.Length);
                    string data1Detail = Encoding.UTF8.GetString(data1);
                    txtFileContents.Text = data1Detail;

                    reader.Close();
                    stream.Close();
                    client.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnCache_Click(object sender, EventArgs e)
        {
            Cache cache = new Cache();
            cache.cacheFrom();
        }
    }
}